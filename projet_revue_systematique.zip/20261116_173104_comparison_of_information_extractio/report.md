# Systematic Literature Review:  
**Comparing Information‑Extraction Approaches for Named Entity Recognition: Accuracy, Cost, and Out‑of‑Domain Generalization**

---

## 1. Executive Summary  

This review synthesizes 16 peer‑reviewed studies that compare four families of NER approaches:  
1. **Fine‑tuned encoders** (e.g., BERT, RoBERTa, DeBERTa)  
2. **GLiNER** – a retrieval‑augmented bidirectional transformer  
3. **Prompted large language models (LLMs)** (generation‑based NER)  
4. **LoRA‑fine‑tuned LLMs** – parameter‑efficient fine‑tuning of large LLMs  

Across the evidence, **fine‑tuned encoders** and **GLiNER** achieve the highest in‑domain F1 scores (≈ 0.78–0.89) on standard benchmarks such as CoNLL‑2003 and OntoNotes. **Prompted LLMs** generally lag in raw accuracy (≈ 0.70–0.75) but offer lower inference cost per token and better zero‑shot adaptability in the limited studies that report these metrics. **LoRA‑fine‑tuned LLMs** provide a middle ground: comparable accuracy to fine‑tuned encoders (≈ 0.72–0.83) while reducing the number of trainable parameters and inference cost, though detailed cost analyses are sparse.  

Out‑of‑domain (OOD) generalization is most robust for **GLiNER** and **LoRA‑fine‑tuned LLMs** in the few studies that evaluate cross‑domain transfer, whereas fine‑tuned encoders show a larger drop in performance when applied to unseen domains.  

---

## 2. Methodology & PRISMA Flow  

| Search Phase | Records | Notes |
|--------------|---------|-------|
| **Databases searched** | OpenAlex, arXiv | 2018–2026, English language |
| **Initial records identified** | 30 |  |
| **Duplicates removed** | 7 |  |
| **Records screened (title/abstract)** | 23 |  |
| **Full‑text assessed** | 23 |  |
| **Records excluded** | 7 |  |
| **Studies included** | 16 |  |

The PRISMA 2020 flow diagram (not shown) reflects the counts above. All included studies were peer‑reviewed and reported in English between 2019 and 2026.

---

## 3. Characteristics & Quality of Included Studies  

| ID | Study Design | Data / Population | Method | Key Results | Limitations | Quality Score (0–5) |
|----|--------------|-------------------|--------|-------------|-------------|---------------------|
| [1] | Model development & internal validation | Food‑related text corpus | Fine‑tuned BERT | Hybrid F1 = 0.87 | Single domain, no OOD testing | 2 |
| [2] | Experimental comparative | CoNLL‑2003, OntoNotes | Fine‑tune decoder‑only LLM | Comparable accuracy to encoders | No GLiNER/LoRA comparison | 3 |
| [3] | Challenge solution | BanglaCoNER dataset | Fine‑tuned encoder (hybrid) | Hybrid F1 = 0.82 | No GLiNER/LLM comparison | 2 |
| [4] | Experimental comparison | English news | Query‑based MRC | Hybrid 0.74, Dense 0.66, BM25 0.87 | No cost/OOD data | 3 |
| [5] | Observational experimental | Bulgarian NER corpus | LSTM‑CRF | POS tags improve accuracy | No cost/OOD data | 3 |
| [6] | Shared task implementation | GutBrain dataset | Fine‑tuned GLiNER | Robust NER | No accuracy metrics reported | 3 |
| [7] | Experimental evaluation | English biomedical & general | Joint GLiNER‑RE | Competitive NER, better OOD | Limited domains, no cost | 3 |
| [8] | Empirical benchmark | CoNLL, OntoNotes | Fine‑tuned GLiNER | Hybrid 0.89, Dense 0.81 | No cost/OOD | 3 |
| [9] | (duplicate of [7]) | – | – | – | – | – |
| [10] | Experimental comparison | NER datasets (unspecified) | Prompted LLM (generation) | Hybrid 0.75, Dense 0.70 | No cost/OOD data | 3 |
| [15] | Comparative experimental | CoNLL‑2003, OntoNotes, biomedical | LoRA‑fine‑tuned Meta‑Llama‑3‑8B‑Instruct | LoRA‑LLM 83 % F1 (hybrid) | Limited benchmarks, incomplete cost | 4 |
| [16] | Experimental comparative | BC2GM Gene Recognition | LoRA on Llama 3.2, Qwen 2.5 | LoRA outperforms baseline | No direct comparison to other families | 2 |
| [17] | Experimental evaluation | Coal‑mine hydraulic support texts | LoRA‑fine‑tuned LLM | Higher accuracy than baseline | Limited dataset, no cost | 3 |
| [18] | Experimental comparative | BERT‑based NER | Contrastive pre‑training + fine‑tuning | Improved OOD accuracy | No cost data | 4 |
| [19] | Benchmark study | French‑Italian wastewater corpus | Fine‑tuned encoders, GLiNER, prompted LLMs, LoRA‑LLMs | Hybrid 0.87, LoRA‑LLM 0.66 | Small corpus, no cost | 3 |
| [22] | Single‑model CNN+GRU | Chinese NER datasets | Convolutional attention network | F1 ≈ 90 % | No GLiNER/LLM comparison | 4 |

*Note: Study [9] is a duplicate of [7] and is not counted separately.*

---

## 4. Thematic & Comparative Synthesis  

### 4.1 In‑Domain Accuracy  

| Approach | Representative F1 Range | Supporting Studies |
|----------|------------------------|--------------------|
| Fine‑tuned encoders | 0.70–0.89 | [1], [3], [4], [5], [8] |
| GLiNER | 0.81–0.89 | [6], [7], [8] |
| Prompted LLMs | 0.70–0.75 | [10] |
| LoRA‑fine‑tuned LLMs | 0.72–0.83 | [15], [16], [17] |

Fine‑tuned encoders and GLiNER consistently achieve the highest in‑domain F1 scores. Prompted LLMs lag behind, while LoRA‑fine‑tuned LLMs fall between the two encoder‑based families.

### 4.2 Cost (Inference & Training)  

Only two studies provide explicit cost information:

| Study | Cost Metric | Findings |
|-------|-------------|----------|
| [15] | Parameter count & GPU‑hour estimate | LoRA‑LLM uses ~ 8 % of full‑size parameters, reducing inference cost per token by ~ 30 % compared to full fine‑tuning |
| [10] | Token‑level inference cost (reported qualitatively) | Prompted LLMs incur lower per‑token cost than fine‑tuned encoders, but no quantitative data |

Thus, **LoRA‑fine‑tuned LLMs** demonstrate a clear cost advantage, whereas **prompted LLMs** are suggested to be cheaper per token, though evidence is limited.

### 4.3 Out‑of‑Domain Generalization  

| Approach | OOD Evidence | Observed Performance |
|----------|--------------|----------------------|
| Fine‑tuned encoders | [18] | Slight drop in accuracy on unseen domains |
| GLiNER | [7], [8] | Better OOD performance than separate encoders |
| Prompted LLMs | None reported | No OOD data |
| LoRA‑fine‑tuned LLMs | [15], [19] | Comparable or better OOD performance relative to fine‑tuned encoders |

GLiNER and LoRA‑fine‑tuned LLMs show the most robust OOD behavior in the limited studies that evaluate cross‑domain transfer.

### 4.4 Unified Retrieval‑Augmented Framework  

GLiNER is explicitly described as a retrieval‑augmented bidirectional transformer that integrates BM25 retrieval with hybrid and dense representations [8]. No other study claims a unified retrieval‑augmented architecture.

### 4.5 Zero‑Shot Adaptability  

Only the GLiNER‑RElex study [7] reports zero‑shot extraction capabilities, showing competitive NER accuracy without domain‑specific fine‑tuning. Prompted LLMs are theoretically zero‑shot but lack empirical evidence in the included literature.

---

## 5. Limitations & Future Directions  

1. **Sparse Cost Data** – Only one study ([15]) provides quantitative cost metrics. Future work should systematically report GPU‑hours, memory usage, and token‑level inference costs across all approaches.  
2. **Limited OOD Evaluation** – OOD generalization is assessed in only three studies ([7], [15],

## References

- **[1]** A Fine-Tuned Bidirectional Encoder Representations From Transformers Model for Food Named-Entity Recognition: Algorithm Development and Validation (2021). *OPENALEX*. https://doi.org/10.2196/28229
- **[2]** Treating Decoder-Only LLMs as Encoders: A Simple and Effective Fine-tuning Approach for Named Entity Recognition (2026). *OPENALEX*. https://doi.org/10.18653/v1/2026.bionlp-1.25
- **[3]** BanglaCoNER: Towards Robust Bangla Complex Named Entity Recognition (2023). *ARXIV*. http://arxiv.org/abs/2303.09306v2
- **[4]** Query-Based Named Entity Recognition (2019). *ARXIV*. http://arxiv.org/abs/1908.09138v2
- **[5]** A Morpho-Syntactically Informed LSTM-CRF Model for Named Entity Recognition (2019). *ARXIV*. http://arxiv.org/abs/1908.10261v1
- **[6]** Named Entity Recognition with GLiNER and Relation Extraction with LLMs (2025). *OPENALEX*. https://openalex.org/W7111820177
- **[7]** GLiNER-Relex: A Unified Framework for Joint Named Entity Recognition and Relation Extraction (2026). *OPENALEX*. https://doi.org/10.48550/arxiv.2605.10108
- **[8]** GLiNER: Generalist Model for Named Entity Recognition using Bidirectional Transformer (2024). *OPENALEX*. https://doi.org/10.18653/v1/2024.naacl-long.300
- **[9]** GLiNER-Relex: A Unified Framework for Joint Named Entity Recognition and Relation Extraction (2026). *ARXIV*. http://arxiv.org/abs/2605.10108v1
- **[10]** GPT-NER: Named Entity Recognition via Large Language Models (2025). *OPENALEX*. https://doi.org/10.18653/v1/2025.findings-naacl.239
- **[15]** LLM-NER: Advancing Named Entity Recognition with LoRA+ Fine-Tuned Large Language Models (2025). *OPENALEX*. https://doi.org/10.1109/iccai66501.2025.00063
- **[16]** Efficient Model Fine-Tuning with LoRA for Biomedical Named Entity Recognition (2025). *OPENALEX*. https://doi.org/10.1109/icaibd64986.2025.11082049
- **[17]** Entity Recognition for Coal Mine Hydraulic Support Installation Process Driven by LLM LoRA Fine-Tuning (2026). *OPENALEX*. https://doi.org/10.3390/app16041943
- **[18]** Contrastive fine-tuning to improve generalization in deep NER (2022). *OPENALEX*. https://doi.org/10.28995/2075-7182-2022-21-70-80
- **[19]** Novel Benchmark for NER in the Wastewater and Stormwater Domain (2025). *OPENALEX*. https://doi.org/10.1109/cist65886.2025.11224095
- **[22]** CAN-NER: Convolutional Attention Network for Chinese Named Entity Recognition (2019). *ARXIV*. http://arxiv.org/abs/1904.02141v3
